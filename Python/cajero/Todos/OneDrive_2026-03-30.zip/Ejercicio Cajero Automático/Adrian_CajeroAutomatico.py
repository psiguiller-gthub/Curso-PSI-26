
def es_multiplo_de(numero, multiplicador):
    return numero % multiplicador == 0

class CajeroAutomatico:
    """tiene una cantidad de billetes y procesa la transaccion del cliente
    """
    def __init__(self, stock_Billetes):
        self.stock_billetes = stock_Billetes

    """compara que monto sea mayor a stockBilletes
    """
    def validar_efectivo_disponible(self, monto):
        return monto <= self.stock_billetes
    

    """descuenta el monto del saldo del stock de la instancia
    """
    def retirar_efectivo(self, monto):
        self.stock_billetes -= monto


class CuentaBancaria:
    """Cuenta bancaria de un usuario

    """
    def __init__(self, numero_cuenta, saldo):
        self.numeroCuenta = numero_cuenta
        self.saldo = saldo

    """devuelve el saldo de la cuenta
    """
    def consultar_saldo(self):
        return self.saldo

    """retira el saldo de la cuenta instanciada
    """
    def debitar(self, monto):
        self.saldo -= monto


class Transaccion:

    #usuario retira dinero
    def retirar_dinero(cajero, cuenta_bancaria, monto):

        #monto multiplo de 10
        if (es_multiplo_de(monto, 10)):
            
            
            #comprobar saldo en la cuenta
            if( cuenta_bancaria.consultar_saldo() > monto ):
                
                
                #comprobar dinero efectivo en el cajero
                if ( cajero.validar_efectivo_disponible(monto) ):
                    cuenta_bancaria.debitar(monto)
                    cajero.retirar_efectivo(monto)
                    print("Dinero retirado")

                else:
                    print("Lo sentimos, en estos momentos este cajero no dispone de suficiente saldo, sea atendido en oficina")

            else:
                print("No dispone de suficiente saldo")

        else:
            print("Ingrese un numero multiplo de 10")


#casos de uso

        """pequenia funcion para imprimir los saldo de cajero y cuenta
        """
def imprimir_saldos(cajero, cuenta):
    print(f"El cajero tiene: {cajero.stock_billetes} en biletes")
    print(f"La cuenta bancaria tiene: {cuenta.consultar_saldo()} de saldo")


#situacion inicial
cajero = CajeroAutomatico(stock_Billetes= 5000)
cuenta_bancaria = CuentaBancaria(numero_cuenta="ES456789123", saldo=1000)
print()

#uso normal
#se puede sacar dinero de la cuenta bancaria y el cajero tiene stock
print(f"-----caso normal------")
monto = 300
print(monto)
Transaccion.retirar_dinero(cajero, cuenta_bancaria, monto)# exito
imprimir_saldos(cajero, cuenta_bancaria)
print()

print("otra retirada de dinero normal")
monto = 500
print(monto)
Transaccion.retirar_dinero(cajero, cuenta_bancaria,monto)# exito
imprimir_saldos(cajero, cuenta_bancaria)
print()



#el usuario introduce un numero no multiplo de 10
print(f"-----el usuario introduce un numero no multiplo de 10 -----------")
monto = 255
print(monto)
Transaccion.retirar_dinero(cajero, cuenta_bancaria,monto)# Ingrese un numero multiplo de 10
imprimir_saldos(cajero, cuenta_bancaria)
print()


#el usuario no dispone de saldo
print(f"----------el usuario no dispone de saldo---------")
monto = 1500
print(monto)
Transaccion.retirar_dinero(cajero, cuenta_bancaria,monto)# no dispone de suficiente saldo
imprimir_saldos(cajero, cuenta_bancaria)
print()


#el cajero no dispone de suficiente saldo
print(f"-----------el cajero no tiene suficiente dinero------------")
print("nuevos valores para cajero y cuenta bancaria")
cajero = CajeroAutomatico(stock_Billetes= 500)
cuenta_bancaria = CuentaBancaria(numero_cuenta="ES456789123", saldo=1500)
Transaccion.retirar_dinero(cajero, cuenta_bancaria, monto)
imprimir_saldos(cajero, cuenta_bancaria)

monto = 1000
Transaccion.retirar_dinero(cajero, cuenta_bancaria,monto)#  ...este cajero no dispone de suficiente...
imprimir_saldos(cajero, cuenta_bancaria)
print()
