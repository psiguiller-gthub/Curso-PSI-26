class CuentaBancaria:
    def __init__(self, numero_cuenta, saldo_inicial):
        self.numero_cuenta_1 = numero_cuenta
        self.saldo = saldo_inicial

    def consultar_saldo(self):
        return self.saldo

    def debitar(self, monto):
        if monto <= self.saldo:
            self.saldo -= monto
            return True
        return False


class CajeroAutomatico:
    def __init__(self, stock_inicial):
        self.stock_efectivo = stock_inicial

    def validar_efectivo_disponible(self, monto):
        return monto <= self.stock_efectivo

    def retirar_efectivo(self, monto):
        if self.validar_efectivo_disponible(monto):
            self.stock_efectivo -= monto
            return True
        return False


class Transaccion:
    def __init__(self, cuenta, cajero):
        self.cuenta = cuenta
        self.cajero = cajero

    def procesar_retiro(self, monto):
        print(f"\n--- Iniciando retiro de {monto}€ ---")
        
        # Regla 3: Múltiplos de 10
        if monto % 10 != 0:
            print("Error: Solo se pueden retirar múltiplos de 10€.")
            return

        # Regla 1: Validación de Saldo del Cliente
        if monto > self.cuenta.consultar_saldo():
            print("Error: Saldo insuficiente en su cuenta.")
            return

        # Regla 2: Límite de efectivo en el Cajero
        if not self.cajero.validar_efectivo_disponible(monto):
            print("Error: El cajero no dispone de efectivo suficiente.")
            return

        # Regla 4: Actualización de ambos sistemas
        # Si llegamos aquí, todas las reglas se cumplen
        self.cuenta.debitar(monto)
        self.cajero.retirar_efectivo(monto)
        
        print("Transacción exitosa.")
        print(f"Nuevo saldo cuenta: {self.cuenta.consultar_saldo()}€")
        print(f"Efectivo restante en cajero: {self.cajero.stock_efectivo}€")
        
   
cuenta_bancaria = CuentaBancaria("123456789", 1000)
cajero_automatico = CajeroAutomatico(1000)
transaccion = Transaccion(cuenta_bancaria, cajero_automatico)
transaccion.procesar_retiro(100)

cuenta_bancaria_2 = CuentaBancaria("987654321", 5)
cajero_automatico_2 = CajeroAutomatico(500)
transaccion_2 = Transaccion(cuenta_bancaria_2, cajero_automatico_2)
transaccion_2.procesar_retiro(50)
