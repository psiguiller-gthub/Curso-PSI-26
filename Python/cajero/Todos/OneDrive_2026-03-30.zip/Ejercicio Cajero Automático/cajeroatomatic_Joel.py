# Crear tres clases en el código Cajero Automático
class CuentaBancaria:
    def __init__(self, numero_cuenta, saldo_inicial):
        self.numero_cuenta = numero_cuenta
        self.saldo = saldo_inicial
        self.exito = False

    def consultarSaldo(self):
        print(f"Saldo actual: {self.saldo}€")

    def debitar(self, monto):
        self.exito = False
        if monto <= self.saldo:
            self.saldo -= monto
            self.exito = True

class CajeroAutomatico:
    def __init__(self, efectivo_disponible):
        self.efectivo_disponible = efectivo_disponible
        self.disponible = False
        self.exito = False

    def validarEfectivoDisponible(self, monto):
        if monto <= self.efectivo_disponible:
            self.disponible = True
        else:
            self.disponible = False

    def retirarEfectivo(self, monto):
        self.exito = False
        if self.disponible:
            self.efectivo_disponible -= monto
            self.exito = True

class Transaccion:
    def __init__(self, cuenta, cajero):
        self.cuenta = cuenta
        self.cajero = cajero

    def retirar(self, monto):
        print(f"\nIntentando retirar {monto}€...")

        exito = True
        mensaje = ""

        # Regla 1: múltiplos de 10
        if monto % 10 != 0:
            mensaje = "X Error X: El monto debe ser múltiplo de 10€"
            exito = False

        # Regla 2: validación de saldo
        elif monto > self.cuenta.saldo:
            mensaje = "X Error X: Saldo insuficiente en la cuenta"
            exito = False

        # Regla 3: efectivo en cajero
        else:
            self.cajero.validarEfectivoDisponible(monto)
            if not self.cajero.disponible:
                mensaje = "X Error X: El cajero no tiene suficiente efectivo"
                exito = False

        # Regla 4: ejecución
        if exito:
            self.cuenta.debitar(monto)
            self.cajero.retirarEfectivo(monto)

            if self.cuenta.exito and self.cajero.exito:
                mensaje = "$ Retiro exitoso $"
            else:
                mensaje = "X Error en la transacción"
                exito = False

        # Resultado final
        print(mensaje)

        if exito:
            self.cuenta.consultarSaldo()
            print(f"Efectivo restante en el cajero: {self.cajero.efectivo_disponible}€")

# ==========================================
# CASOS DE USO
# ==========================================

cuenta = CuentaBancaria("ES123", 1500)
cajero = CajeroAutomatico(1000)
transaccion = Transaccion(cuenta, cajero)

print("*" * 50)
transaccion.retirar(100)   # OK
print("+" * 50)
transaccion.retirar(559)   # Error múltiplo
print("*" * 50)
transaccion.retirar(2000)  # Error saldo
print("+" * 50)
transaccion.retirar(1000)  # Error cajero
print("*" * 50)