class CuentaBancaria:
    """Almacena el saldo del cliente, su nombre y el número de cuenta."""
    
    # Inicializa la cuenta con un número, nombre y saldo inicial.
        
        # Parámetros: numero_cuenta (str), nombre_cliente (str), saldo_inicial (float)
        # Ejemplo: CuentaBancaria("12345-X", "Juan Pérez", 500)
       
        # Atributos:
        # - numero_cuenta: str
        # - nombre_cliente: str
        # - saldo: float
        
        # Métodos:
            # - consultarSaldo(): Devuelve el saldo actual de la cuenta.
            # - debitar(monto): Disminuye el saldo en la cantidad especificada.

    def __init__(self, numero_cuenta, nombre_cliente, saldo_inicial):
        self.numero_cuenta = numero_cuenta
        self.nombre_cliente = nombre_cliente
        self.saldo = saldo_inicial

    def consultarSaldo(self):
        print(f"Saldo actual: {self.saldo}")

    def debitar(self, monto):
        self.saldo -= monto

class CajeroAutomatico:
    """Gestiona el dinero físico disponible en la máquina."""

    # Inicializa el cajero con una cantidad de efectivo disponible.
        
        # Parámetros: efectivo_disponible (float)
        # Ejemplo: CajeroAutomatico(1000)
        
        # Atributos:
        # - efectivo_disponible: float
        
        # Métodos:
            # - validarEfectivoDisponible(monto): Verifica si el monto puede ser retirado.
            # - retirarEfectivo(monto): Disminuye el efectivo disponible en la cantidad especificada.

    def __init__(self, efectivo_disponible):
        self.efectivo_disponible = efectivo_disponible

    def validarEfectivoDisponible(self, monto):
        if monto <= self.efectivo_disponible:
            disponible = True
        else:
            disponible = False
        self.es_disponible = disponible

    def retirarEfectivo(self, monto):
        self.validarEfectivoDisponible(monto)
        if self.es_disponible:
            self.efectivo_disponible -= monto
            self.operacion_exitosa = True
        else:
            self.operacion_exitosa = False
    

class Transaccion:
    """Orquestador de la interacción entre CuentaBancaria y CajeroAutomatico."""

    # Método para ejecutar el retiro, aplicando las reglas de negocio:
    # 1. El monto debe ser múltiplo de 10.
    # 2. El saldo en la cuenta debe ser suficiente para el retiro.

    # Parámetros: cuenta (CuentaBancaria), cajero (CajeroAutomatico), monto (float)
    
    # Ejemplo: ejecutarRetiro(mi_cuenta, mi_cajero, 100)
    # Retorna un mensaje indicando el resultado de la transacción.
    

    def ejecutarRetiro(self, cuenta, cajero, monto):
        # 1. Regla de múltiplos de 10
        if monto % 10 != 0:
            mensaje = "Error: El monto debe ser múltiplo de 10."
        else:
            # 2. Regla de saldo suficiente en cuenta
            if monto > cuenta.saldo:
                mensaje = "Error: Saldo insuficiente en la cuenta bancaria."
            else:
                # 3. Regla de efectivo disponible en el cajero
                cajero.validarEfectivoDisponible(monto)
                if not cajero.es_disponible:
                    mensaje = f"Error: El cajero no tiene suficiente efectivo (Disponible: {cajero.efectivo_disponible})."
                else:
                    # Ejecución de la transacción
                    cuenta.debitar(monto)
                    cajero.retirarEfectivo(monto)
                    mensaje = (f"Transacción exitosa. Retirado: {monto}. "
                               f"Saldo restante en cuenta: {cuenta.saldo}. "
                               f"Efectivo restante en cajero: {cajero.efectivo_disponible}.")
        print(mensaje)

# --- Ejemplo de uso ---
if __name__ == "__main__":
    mi_cuenta = CuentaBancaria("12345-X", "Juan Pérez", 500)
    mi_cajero = CajeroAutomatico(1000)
    gestor_transacciones = Transaccion()

    mi_cuenta.consultarSaldo()
    
    # Intentar transacciones
    gestor_transacciones.ejecutarRetiro(mi_cuenta, mi_cajero, 75)
    gestor_transacciones.ejecutarRetiro(mi_cuenta, mi_cajero, 100)
    gestor_transacciones.ejecutarRetiro(mi_cuenta, mi_cajero, 450)
    gestor_transacciones.ejecutarRetiro(mi_cuenta, mi_cajero, 400)
    gestor_transacciones.ejecutarRetiro(mi_cuenta, mi_cajero, 50)
    gestor_transacciones.ejecutarRetiro(mi_cuenta, mi_cajero, 30)

    mi_cuenta.consultarSaldo()
    print(f"Efectivo disponible en el cajero: {mi_cajero.efectivo_disponible}")
