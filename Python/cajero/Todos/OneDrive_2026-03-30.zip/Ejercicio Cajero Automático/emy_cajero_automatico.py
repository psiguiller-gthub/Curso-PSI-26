class CuentaBancaria:
    def __init__(self, saldo_inicial):
        self.saldo = saldo_inicial

    def consultar_saldo(self):
        return self.saldo   
        
    def retirar_efectivo(self, monto):
        if monto <= self.saldo:
            self.saldo -= monto
            return True
        return False


class CajeroAutomatico:
    def __init__(self, efectivo_disponible):
        self.cuenta = CuentaBancaria(efectivo_disponible)

    def validar_efectivo_disponible(self, monto):
        if monto <= self.cuenta.consultar_saldo():
            return True
        return False

    def retirar_efectivo(self, monto):
        if self.cuenta.retirar_efectivo(monto):
            print(f"Retiro de {monto} realizado.")
        else:
            print("Fondos insuficientes.")


class Transaccion:
    def __init__(self, cuenta, cajero, monto):
        self.cuenta = cuenta
        self.cajero = cajero
        self.monto = monto

    def ejecutar(self):
       
        if self.monto % 10 != 0:
            print("Error: Solo se permiten múltiplos de 10€")
            return

       
        saldo_cuenta = self.cuenta.consultar_saldo()
        if (self.monto <= saldo_cuenta) and (self.monto <= self.cajero.cuenta.consultar_saldo()):
            restar_saldo = saldo_cuenta - self.monto
            print(f"Saldo restante en la cuenta: {restar_saldo}€")
            print(f"Retiro de {self.monto}€ realizado con éxito")
            
          
            self.cuenta.retirar_efectivo(self.monto)
            self.cajero.retirar_efectivo(self.monto)
        else:
            if self.monto > saldo_cuenta:
                print("Error: Saldo insuficiente")
            else:
                print("Error: Cajero sin suficiente efectivo")


#main

cuenta = CuentaBancaria(300)
cajero = CajeroAutomatico(200)

transaccion = Transaccion(cuenta, cajero, 150)
transaccion.ejecutar()