class CuentaBancaria:
    def __init__(self, numero_cuenta, saldo_inicial):
        self.numero_cuenta = numero_cuenta
        self.saldo = saldo_inicial

    def consultar_saldo(self):
        return self.saldo
    
    def debitar(self, monto):
        if monto <= self.saldo:
            self.saldo -= monto 
            return True
        return False
    

class CajeroAutomatico:
    def __init__(self, efectivo_disponible):
        self.efectivo_disponible = efectivo_disponible

    def validar_efectivo_disponible(self, monto):
        return monto <= self.efectivo_disponible
    
    def retirar_efectivo(self, monto):
        if self.validar_efectivo_disponible(monto):
            self.efectivo_disponible -= monto
            return True
        return False
    

class Transaccion:
    def __init__(self, cuenta, cajero):
         self.cuenta = cuenta
         self.cajero = cajero

    def procesar_retiro(self, monto):
        print(f"\n--- Iniciando transacción de {monto}€ ---")

        if monto % 10 != 0:
            print("Error: Solo se pueden retirar múltipolos de 10€.")
            return
            
        if monto > self.cuenta.consultar_saldo():
            print("Error: Saldo insuficiente en la cuenta.")
            return

        if not self.cajero.validar_efectivo_disponible(monto):
            print("Error: El cajero no dispone de efectivo suficiente.")
            return
            
        if self.cuenta.debitar(monto):
            cajero.retirar_efectivo(monto)
            print("Exito: retire su dinero.")
            print(f"Saldo restante en cuenta: {self.cuenta.consultar_saldo()}€")
        else:
            print("Error: No se pudo procesar el débito.")


# casos de uso 
cuenta = CuentaBancaria ("ES123",1200)
cajero = CajeroAutomatico(1000)

transaccion = Transaccion(cuenta, cajero)
transaccion.procesar_retiro(200)

