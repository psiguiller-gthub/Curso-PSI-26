#Simulacion retirada en cajero automatico


saldo_cajero = 1000
numero_cuenta= 123456
saldo_cliente=2000


class Cuentabancaria:
    def __init__(self,numero_cuenta, saldo_cliente):
        self.numero_cuenta = numero_cuenta
        self.saldo_cliente = saldo_cliente

    def consultar_saldo(self):
        print(f"Saldo actual: {self.saldo_cliente}")
        return self.saldo_cliente

    def debitar(self, monto):
        if monto <= self.saldo_cliente:
            self.saldo_cliente -= monto
            print(f"Se debitaron {monto}. Saldo restante: {self.saldo_cliente}")
        else:
            print("Saldo insuficiente para realizar el débito.")

class CajeroAutomatico:
    def __init__(self, saldo_cajero):
        self.saldo_cajero= saldo_cajero

    def validarEfectivoDisponible(self, monto):
        if monto <= self.saldo_cajero:
            return True
        else:
            return False
    def retirarEfectivo(self, monto):
        if monto <= self.saldo_cajero:
            self.saldo_cajero -= monto
            print(f"Se retiraron {monto}. Saldo restante en cajero: {self.saldo_cajero}")
        else:
            print("No se puede retirar el monto solicitado. Saldo insuficiente en el cajero.")
    
    

class Transaccion:
    def realizarRetiro(self, cuenta, cajero, monto):

        if monto % 10 != 0:
            print("El monto debe ser múltiplo de 10 !!")
        else:
            if monto > cuenta.consultar_saldo():
                print("El monto es mayor que el saldo disponible !!")
            if not cajero.validarEfectivoDisponible(monto):
                print("No hay suficiente efectivo en el cajero !!")
            else:
                cuenta.debitar(monto)
                cajero.retirarEfectivo(monto)
                print("Retiro realizado con éxito !!")


cuenta = Cuentabancaria(numero_cuenta, saldo_cliente)
cajero = CajeroAutomatico(saldo_cajero)
transaccion = Transaccion()

# --- CASOS DE USO ---

# Caso 1: Monto no múltiplo de 10
print("\nCaso 1: Monto no múltiplo de 10")
transaccion.realizarRetiro(cuenta, cajero, 25)  # Error por no ser múltiplo de 10

# Caso 2: Monto mayor al saldo del cliente
print("\nCaso 2: Monto mayor que el saldo del cliente")
transaccion.realizarRetiro(cuenta, cajero, 3000)  # Error por saldo insuficiente

# Caso 3: Monto mayor al saldo del cajero
print("\nCaso 3: Monto mayor que el saldo del cajero")
transaccion.realizarRetiro(cuenta, cajero, 1500)  # Error por efectivo insuficiente en cajero

# Caso 4: Retiro válido
print("\nCaso 4: Retiro válido")
transaccion.realizarRetiro(cuenta, cajero, 500)  # Retiro exitoso

# Caso 5: Retiro que deja saldo exacto del cajero
print("\nCaso 5: Retiro que agota el saldo del cajero")
transaccion.realizarRetiro(cuenta, cajero, 500)  # Retiro exitoso, cajero queda con 0






































